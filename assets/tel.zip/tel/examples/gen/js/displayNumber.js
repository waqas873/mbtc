var input = document.querySelector("#phone");
window.intlTelInput(input, {
  utilsScript: "../../build/js/utils.js?1613236686837" // just for formatting/placeholders etc
});
