<!DOCTYPE html>
<html lang="zxx" class="js">
	<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="CryptoCoin is a powerful Bitfair Crypto Currency Wallet and Mining Template with full of customization options and features">
		<!-- Fav Icon  -->
		<link rel="shortcut icon" href="images/images _3.png">
		<!-- Site Title  -->
		<title>Qnet.net</title>
		<base href="<?php echo base_url();?>">
		<!-- Vendor Bundle CSS -->
		<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
		<link href="publicsite/assets/js/wow.min.js" rel="stylesheet">
	    <link href="publicsite/assets/css/vendor/animate.css" rel="stylesheet">
		<link rel="stylesheet" href="publicsite/assets/css/vendor.bundle.css">
		<link href="publicsite/assets/css/style.css" rel="stylesheet">
		<link href="publicsite/assets/css/style_1.css" rel="stylesheet">
		<link href="publicsite/assets/css/theme.css" rel="stylesheet">
	    <link rel="stylesheet" type="text/css" href="publicsite/sliderengine/amazingslider-1.css">
		<link href="assets/css/theme-cyan.css" rel="stylesheet">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
		<script>
	      var base_url = '<?php echo base_url(); ?>';
	    </script>
	    <script type="text/javascript" src="publicsite/assets/js/wow.js"></script>

<style class="cp-pen-styles">
html, body { overflow-x: hidden;
        background: rgba(255,255,255,.7);
    background-size: contain;
     }
     .wrap_slick {
       position: relative;
       z-index: 100;
       width: 100%;
       height: 100%;
       padding: 0 60px;
       background-image: url("<?php echo base_url(); ?>/publicsite/images/watches_and_jewellery.jpg");
        background-attachment: fixed;
        background-size: cover;
       overflow: hidden;
       padding: 100px 0px 0px 0px;
     }

     .wrap_slick:after {
       content:'';
       position: absolute;
       z-index: 2;
       top: 0;
       left: 0;
       right: 0;
       bottom: 0;
       background: rgba(0,0,0,.5);
     }

     .slider {
       position: relative;
       z-index: 200;
       padding: 0 0px;
       margin: 5rem auto;
       max-width: 800px;
       width: 100%;
     }

     .slick-arrow {
       position: absolute;
       top: 50%;
       width: 40px;
       height: 50px;
       line-height: 50px;
       margin-top: -25px;
       border: none;
       background: transparent;
       color: #fff;
       font-family: monospace;
       font-size: 5rem;
       z-index: 300;
       outline: none;
     }

     .slick-prev {
       left: -50px;
       text-align: left;
     }

     .slick-next {
       right: -50px;
       text-align: right;
     }
     .item.slick-slide {
       width: 320px;
       height: 425px !important;
       transition: -webkit-transform .4s;
       transition: transform .4s;
       transition: transform .4s, -webkit-transform .4s;
       position: relative; 
     }

     .slick-slide:after {
       content:'';
       position: absolute;
       z-index: 2;
       top: 0;
       left: 0;
       right: 0;
       bottom: 0;
       background: rgba(0,0,0,.5);
       transition: -webkit-transform .4s;
       transition: transform .4s;
       transition: transform .4s, -webkit-transform .4s;
     }

     .item.slick-slide {
       -webkit-transform: scale(0.7)  translate(640px);
               transform: scale(0.7)  translate(640px);
     }

     .item.slick-slide.slick-center + .slick-slide {
       -webkit-transform: scale(0.8) translate(-250px);
               transform: scale(0.8) translate(-250px);
       z-index: 10;
     }

     .item.slick-slide.slick-center + .slick-slide + .item.slick-slide {
       -webkit-transform: scale(0.7)  translate(-640px);
               transform: scale(0.7)  translate(-640px);
       z-index: 5;
     }

     .item.slick-slide.slick-active {
       -webkit-transform: scale(0.8) translate(250px);
               transform: scale(0.8) translate(250px);
     }

     .item.slick-slide.slick-center {
       /* margin: 0 -10%; */
       -webkit-transform: scale(1);
               transform: scale(1);
       z-index: 30;
     }

     .slick-center:after {
       opacity: 0;
     }
#carousel3d .carousel-3d-slide {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-flex: 1;
      -ms-flex: 1;
          flex: 1;
  -webkit-box-orient: vertical;
  -webkit-box-direction: normal;
      -ms-flex-direction: column;
          flex-direction: column;
  -webkit-box-pack: center;
      -ms-flex-pack: center;  
          justify-content: center;
  text-align: center;
  background-color: #fff;
  padding: 10px;
  -webkit-transition: all .4s;
  transition: all .4s;
}
#carousel3d .carousel-3d-slide.current {
  background-color: #078cd6;
  color: #fff;
}
#carousel3d .carousel-3d-slide.current span {
  font-size: 20px;
  font-weight: 500;
}
.bg-grey {
  background-image: url("<?php echo base_url(); ?>/publicsite/images/watches_and_jewellery.jpg");
  background-attachment: fixed;
  background-size: cover;
 
}

#pekiges_sec{
	background-image: url("<?php echo base_url(); ?>/publicsite/images/bitcoin_6.jpg");
  background-attachment: fixed;
  background-size: cover;

}

#bitfair_news{
  
  background-image: url("<?php echo base_url(); ?>/publicsite/images/watches_and_jewellery.jpg");
  background-attachment: fixed;
  background-size: cover;
}

#INVESTORS_seC{

 background-image: url("<?php echo base_url(); ?>/publicsite/images/watches_and_jewellery.jpg");
  background-attachment: fixed;
  background-size: cover;	
  padding-bottom: 70px;
}


.next[data-v-43e93932], .prev[data-v-43e93932]{
	color: #fff !important;
}

.amazingslider-box-1 a{
opacity: 0;
}
.amazingslider-box-1 div:last-child{
  background-color: transparent!important;
}

@media(max-width: 580px){
	.box_4 {padding:0px !Important;padding-top: 10px;}
	.testimonial-item .client-photo {margin-bottom: 20px;margin-top: 20px !important;}
	.testimonial-item iframe {width: 100% !important;}
}
</style>

              <script>
              new WOW().init();
              </script>

	</head>
	<body>
	
		<!-- Header --> 
		

		{_yield}



		
       	<!-- Section Footer -->
		<div class="footer-section section section-pad-md light bg-footer wow slideInLeft">
			<div class="imagebg footerbg i_c18">
				<!-- <img src="images/footer-bg.png" alt="footer-bg"> -->
			</div>
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-sm-6 col-xs-6 wgs-box res-m-bttm">
						<!-- Each Widget -->
						<div class="wgs-footer wgs-menu">
							<h5 class="wgs-title ucap">Services</h5>
							<div class="wgs-content">
								<ul class="menu">
									<li><a href="#">Buy Bitcoins</a></li>
									<li><a href="#">Buy Ethereum</a></li>
									<li><a href="#">Sell Bitcoins</a></li>
									<li><a href="#">Bitcoin Trading</a></li>
									<li><a href="#">Margin Trading</a></li>
								</ul>
							</div>
						</div>
						<!-- End Widget -->
					</div>
					<div class="col-md-3 col-sm-6 col-xs-6 wgs-box res-m-bttm">
						<!-- Each Widget -->
						<div class="wgs-footer wgs-menu">
							<h5 class="wgs-title ucap">Information</h5>
							<div class="wgs-content">
								<ul class="menu">
									<li><a href="#">Payment Options</a></li>
									<li><a href="#">Fee Schedule</a></li>
									<li><a href="#">Getting Started</a></li>
									<li><a href="#">Identity Verification Guide</a></li>
									<li><a href="#">Card Verification Guide</a></li>
								</ul>
							</div>
						</div>
						<!-- End Widget -->
					</div>
					<!-- <div class="col-md-3 col-sm-6 col-xs-6 wgs-box res-m-bttm">
						<div class="wgs-footer wgs-post">
							<h5 class="wgs-title ucap">Recent Blog</h5>
							<div class="wgs-content">
								<div class="wgs-post-single">
									<div class="wgs-post-thumb">
										<img src="images/unnamed.jpg" alt="post-thumb">
									</div>
									<div class="wgs-post-entry">
										<h6 class="wgs-post-title"><a href="blog-single.html">Working Hard to Keep Pace with Demand </a></h6>
										<span class="wgs-post-meta">December 19, 2017</span>
									</div>
								</div>
								<div class="wgs-post-single">
									<div class="wgs-post-thumb">
										<img src="images/333.jpg" alt="post-thumb">
									</div>
									<div class="wgs-post-entry">
										<h6 class="wgs-post-title"><a href="blog-single.html">Working Hard to Keep Pace with Demand </a></h6>
										<span class="wgs-post-meta">December 19, 2017</span>
									</div>
								</div>
							</div>
						</div>
					</div> -->
					<div class="col-md-3 col-sm-6 col-xs-6 wgs-box res-m-bttm">
						<!-- Each Widget -->
						<div class="wgs-footer wgs-contact">
							<h5 class="wgs-title ucap">get in touch</h5>
							<div class="wgs-content">
								<ul class="wgs-contact-list">
									<!-- <li><span class="pe pe-7s-map-marker"></span>217 Summit Boulevard <br/>Birmingham, AL 35243</li>
									<li><span class="pe pe-7s-call"></span>Telephone : (123) 4567 8910 <br/>Telephone : (123) 1234 5678</li> -->
									<li>
                    <span class="pe pe-7s-global" style="float: left;top: 0px;"></span>
                    <span>
                      Web : <a href="javascript::">www.qnet.global</a>
                    </span>
                  </li>
                  <li>
                    <span class="pe pe-7s-mail" style="float: left;top: 0px;"></span>
                    <span>
                      <a href="javascript::">Support@qnetglobal.co</a>
                    </span>
                  </li>
								</ul>
							</div>
						</div>
						<!-- End Widget -->
					</div>
				</div>
			</div>	
		</div>
		<!-- End Section -->
		
		<!-- Copyright -->
		<div class="copyright light">
			<div class="container">
				<div class="row">
					<div class="site-copy col-sm-7 col-xs-7">
						<p>Copyright &copy; 2018.Powered by <a href="#">QNet</a></p>
					</div>
					<div class="col-sm-5 col-xs-5 text-right mobile-left">
						<ul class="social">
							<li><a href="#"><em class="fa fa-facebook"></em></a></li>
							<li><a href="#"><em class="fa fa-twitter"></em></a></li>
							<li><a href="#"><em class="fa fa-linkedin"></em></a></li>
							<li><a href="#"><em class="fa fa-google-plus"></em></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- End Copyright -->
		
		<!-- Preloader !remove please if you do not want -->
		<div id="preloader"><div id="status">&nbsp;</div></div>
		<!-- Preloader End -->
		
		<!-- JavaScript
		================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->

		<script src="https://maps.google.com/maps/api/js?key=AIzaSyCLZzq31lWF8Oo31xbFTqHchlmXIfzqeAI"></script> 
		<script src="publicsite/assets/js/googleMap.js"></script>

		<script src="publicsite/assets/js/jquery.bundle.js"></script>
		<script src="publicsite/assets/js/script.js"></script>
		<script>
		  (function(b,i,t,C,O,I,N) {
			window.addEventListener('load',function() {
			  if(b.getElementById(C))return;
			  I=b.createElement(i),N=b.getElementsByTagName(i)[0];
			  I.src=t;I.id=C;N.parentNode.insertBefore(I, N);
			},false)
		  })(document,'script','https://widgets.bitfair.com/widget.js','btcwdgt');
		</script>

		

<script src='https://cdnjs.cloudflare.com/ajax/libs/vue/2.1.7/vue.js'></script><script src='https://rawgit.com/Wlada/vue-carousel-3d/master/dist/vue-carousel-3d.min.js'></script>
<script >new Vue({
  el: '#carousel3d',
  data: {
    slides: 7
  },
  components: {
    'carousel-3d': Carousel3d.Carousel3d,
    'slide': Carousel3d.Slide
  }
})
//# sourceURL=pen.js
</script>
<script src="https://code.jquery.com/jquery-2.2.4.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
<script src="publicsite/sliderengine/amazingslider.js"></script>
<script src="publicsite/sliderengine/initslider-1.js"></script>
<!-- 
 <script>
    var browsersSelector = '.hero__browser'
    window.HeroBrowsers.animateBrowsers(browsersSelector, 4500)
 </script>

<script>
       
    $(document).ready(function(){
    $('.navbar-nav li a').click(function() {
      if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'')
      && location.hostname == this.hostname) {
        var $target = $(this.hash);
        $target = $target.length && $target
        || $('[name=' + this.hash.slice(1) +']');
        if ($target.length) {
          var targetOffset = $target.offset().top;
          $('html,body')
          .animate({scrollTop: targetOffset}, 2000);
         return false;
        }
      }
    });
   });
  
</script>
 -->
 <script type="text/javascript">
 	$('.slider').slick({
 	  slidesToShow: 3,
 	  slidesToScroll: 1,
 	  arrows: true,
 	  dots: false,
 	  centerMode: true,
 	  variableWidth: true,
 	  infinite: true,
 	  autoplay: true,
 	  focusOnSelect: true,
 	  cssEase: 'linear',
 	  autoplaySpeed: 3000,
 	  prevArrow:'<button class="slick-prev"> < </button>',
 	  nextArrow:'<button class="slick-next"> > </button>',
 	  
 	  //         responsive: [                        
 	  //             {
 	  //               breakpoint: 576,
 	  //               settings: {
 	  //                 centerMode: false,
 	  //                 variableWidth: false,
 	  //               }
 	  //             },
 	  //         ]
 	});


 	var imgs = $('.slider img');
 	imgs.each(function(){
 	  var item = $(this).closest('.item');
 	  item.css({
 	    'background-image': 'url(' + $(this).attr('src') + ')', 
 	    'background-position': 'center',            
 	    '-webkit-background-size': 'cover',
 	    'background-size': 'cover', 
 	  });
 	  $(this).hide();
 	});
 </script>
	</body>
</html>
