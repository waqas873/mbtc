
	<style>
           .i_c12{
            margin-left:10% !important;
           } 

           @media only screen and (max-width: 767px) {   
               .i_c12{
                margin-left:5% !important;
                } 
           } 
           #section-pad{background-image: url("publicsite/images/watches_and_jewellery.jpg")!important;
    background-attachment: fixed!important;
    background-size: cover!important;}
    #section-pad h5{
      color: #ea670c!important;
    }
     #section-pad p{
      color: #fff!important;
    }
    .has-bg:after {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    content: "";
    background-color: #000;
    opacity: 0.2!important;
    z-index: 1;
}

      </style>
		<!-- Header --> 
		<header class="site-header header-s1 is-sticky">
			
			<?php $this->load->view("publicsite/common_header"); ?>

			<div class="page-head section row-vm light wow lightSpeedIn">
				<div class="imagebg i_c23" style="width: 103% !important;">
					<img src="publicsite/images/shutterstock_759837652-bitcoin-mining-e1543849797576.jpg" alt="page-head">
				</div>
				<div class="container">
					<div class="row text-center i_c24">
						<div class="col-md-12">
							<h2 style="">Service</h2>
							<div class="page-breadcrumb">
								<ul class="breadcrumb">
									<li><a href="<?php echo base_url('publicsite/index');?>">Home</a></li>
									<li class="active"><span>Service</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- #end Banner/Slider -->
		</header>
    	
     	<!--Section -->
       	<div class="section section-pad i_c22 wow fadeInLeft">
       		<div class="container">
       			<div class="row row-vm">
       				<div class="col-md-8 col-sm-12">
						<div class="text-block wow fadeInLeft">
							<h2>Buy QNet Online </h2>
                                          <p>In QNet Company you will find the Best Investment Plans Online. Our 3 Investment Plans yield 2% Upto 12% Daily and Forever. Get your Income Every Day. Withdraw your Funds Daily and Instantly.</p>
						</div>
       				</div>
       				<div class="col-md-4 col-sm-12">
       					<!-- <div class="round mgr--30 res-m-bttm i_c12 wow fadeInRight text-center">
       						<img src="publicsite/images/Money.jpg" alt="photo-md" class="img-shadow i_c13" style="box-shadow: 0 12px 15px rgba(0, 0, 0, 0.05);

position: relative;

top: 0px;

right: 0px;

height: 238px;">
       					</div> -->
       				</div>
       			</div>
       		</div>
       	</div>
       	<!--End Section -->

       	<div class="section section-pad wow bounceInUp" id="section-pad">
       		<div class="container">
       			<div class="section-head">
					<div class="row text-center">
						<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
							<h2 class="heading-section">what you can do ?</h2>
							<p>Sed ut perspi ciatis unde omnis iste natus error sit volup tatem accusa ntium dolor emque lauda ntium, totam rem aperiam</p>
						</div>
					</div>
       			</div>
       			<div class="gaps size-3x"></div>
       			<div class="row text-center">
       				<div class="row">
       				<div class="col-md-4 col-sm-4">
       					<div class="service-box shadow round" >
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/images 123.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry">
       							<h5>Buy QNet Online</h5>
                                                <p>In QNet Company you will find the Best Investment Plans Online. Our 3 Investment Plans yield 2% to 12% Daily and Forever. Get your Income Every Day. Withdraw your Funds Daily and Instantly.</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
						<div class="gaps size-3x"></div>
       				</div>
       				<div class="col-md-4 col-sm-4">
       					<div class="service-box shadow round" >
       						<div class="service-thumb">
       						    <a href="#"><img src="publicsite/images/img123.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry">
       							<h5>sell QNet</h5>
       							<p>Justo dolor pede pede sit. Eu amet eos mauris, iaculis in, fringilla diam eros erat, fermentum etiam parturient est adipiscing</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
						<div class="gaps size-3x"></div>
       				</div>
       				<div class="col-md-4 col-sm-4">
       					<div class="service-box shadow round"  >
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/images 12345.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry">
       							<h5>Earn Passive Income</h5>
                                                <p>We Pay Commissions Three Kind Of Way,First Of All For Our Brilliant Networker (12% Smart Referal Bonus,And Second 8% Matching Solid Bonus)</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
						<div class="gaps size-3x"></div>
       				</div>
       			</div>


       				<div class="row">
       					<div class="col-md-4 col-sm-4 res-m-bttm-3x">
       					<div class="service-box shadow round"  >
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/qnet_honour_roll.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry">
       							<h5>Strong Securiy</h5>
                                                <p>Be QNet Company knows the Online Investment Market, and our Company Guarantees the Payment for all our Investors and Representatives. Invest Today at QNet Company and Get 2% to 12% Daily Forever.</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
       				</div>
       				<div class="col-md-4 col-sm-4 res-m-bttm-3x">
       					<div class="service-box shadow round"  >
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/images112.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry">
       							<h5>Build Your Reputation</h5>
                                                <p>You can join us.By joining us within a short period of time you will be the one of nine and half hundered millionares. You can spend your respectful life.</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
       				</div>
       				<div class="col-md-4 col-sm-4 res-m-bttm-3x">
       					<div class="service-box shadow round"  >
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/mining.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry">
       							<h5>Get A Free Wallet</h5>
                                                <p>We provide new wallets to our all new customers.They can start their new future.</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
       				</div>
       				</div>
       			</div>
       		</div>
       	</div>


		<div class="section section-pad cta-section light has-bg dark-filter i_c21 wow slideInRight">
    		<div class="imagebg i_c19">
				<img src="publicsite/images/branding_and_sports_sponsorships.jpg" alt="cta-bg" >
			</div>
    		<div class="container">
    			<div class="row text-center i_c20">
    				<div class="col-md-8 col-md-offset-2">
    					<h3>Are you searching for a quick, cheap, and safe way to buy QNet? </h3>
    					<a href="#" class="btn btn-md">buy QNet</a>
    				</div>
    			</div>
    		</div>
    	</div>
		
		<!--Section -->
       	<div class="section section-pad wow bounceInUp" >
       		<div class="container">
       			<div class="section-head">
					<div class="row text-center">
						<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
							<h2 class="heading-section">Why this service ?</h2>
							<p style="color: #fff!important;">Sed ut perspi ciatis unde omnis iste natus error sit volup tatem accusa ntium dolor emque lauda ntium, totam rem aperiam</p>
						</div>
					</div>
       			</div>
       			<div class="gaps size-3x"></div>
				<div class="row text-center">
					<div class="col-md-4 res-m-bttm-lg">
						<div class="box-alt">
							<div class="image-icon">
								<img src="publicsite/images/box-icon-f.png" alt="box-icon">
							</div>
							<h4>SPEEDY PAYMENT</h4>
                                          <p>The QNet Company,Values the Speed of the Deposits and Withdrawals.All Deposits and Withdrawals are Processed Instantly to your Account at High Speed and Totally Secure.</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-alt" style="margin-bottom: 50px;">
							<div class="image-icon">
								<img src="publicsite/images/box-icon-g.png" alt="box-icon">
							</div>
							<h4>Strong Security</h4>
                                          <p>Be QNet Company knows the Online Investment Market, and our Company Guarantees the Payment for all our Investors and Representatives. Invest Today at Qnet Company and Get 2% to 12% Daily Forever.</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-alt">
							<div class="image-icon">
								<img src="publicsite/images/box-icon-h.png" alt="box-icon">
							</div>
							<h4>World Coverage</h4>
                                          <p>Be QNet Company offers the best Investment Plans. You can Invest from anywhere in the World and Withdraw your Earnings at any time.</p>
						</div>
					</div>
				</div>
       		</div>
       	</div>
       	<!--End Section -->
      	
       	