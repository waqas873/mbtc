         <style>
         	    @media only screen and (max-width: 992px) {
				.section-pad{
	                 margin-top: -250px;
	              }
				}
				.content h3{
					color: black!important;
				}
				.content h3:hover{
					color: #ea670c!important;
				}
				.timeline span,.fa{
					color: black!important;
				}
				.timeline span,.fa:hover{
					color: #ea670c!important;
				}
         </style>
	
		<!-- Header --> 
		<header class="site-header header-s1 is-sticky">
			
			<?php $this->load->view("publicsite/common_header"); ?>

			<div class="page-head section row-vm light wow lightSpeedIn">
				<div class="imagebg i_c23">
					<img src="publicsite/images/road.png" alt="page-head">
				</div>
				<div class="container">
					<div class="row text-center i_c24">
						<div class="col-md-12">
							<h2>Road Map</h2>
							<div class="page-breadcrumb">
								<ul class="breadcrumb">
									<li><a href="<?php echo base_url('publicsite/index');?>">Home</a></li>
									<li class="active"><span>Road Map</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- #end Banner/Slider -->
		</header>
		                    <div class="section section-pad"> 
								<div class="container">
								    <div class="row">
								        <div class="col">
								            <div class="main-timeline">
								                <div class="timeline">
								                    <a href="#" class="timeline-content">
								                    <span class="timeline-year">2015 Q2</span>
								                    <div class="timeline-icon">
								                        <i class="fa fa-rocket" aria-hidden="true"></i>
								                    </div>
														<div class="content">
														    <h3 class="title">Budding Ideas</h3>
														        <p class="description">
														            Steve frowned upon the poverty and chaos around in the world, with his dedication and crave for peace, decided to take a measure to grant people better lives. Had a wish but didn’t know what path to choose to fulfil it. Hence the man kept giving it thought and lost in thoughts on how he should achieve this massive goal in his life. Steve then reaches out to his beloved friends and confronts his ideas and wishes.
														        </p>
														</div>
												    </a>
								                </div>
								            <div class="timeline">
								                <a href="#" class="timeline-content">
								                    <span class="timeline-year">2015 Q4</span>
								                    <div class="timeline-icon">
								                        <i class="fa fa-users" aria-hidden="true"></i>
								                    </div>
								                        <div class="content">
								                            <h3 class="title">Gathering of the Elite</h3>
								                                <p class="description">
								                                    Steve and his friends gather and are impressed by Steve’s motto, As a thought of giving it a chance and thinking over, Stumbling upon various ideas to grant better life to mankind. They come to an agreement to give it a try with Forex Trading. Team begins its preparations, studies, analysis and start planning their strategies all over till the year end.
								                                </p>
								                        </div>
								                </a>
								            </div>
								<div class="timeline">
								<a href="#" class="timeline-content">
								<span class="timeline-year">2016 Q1</span>
								<div class="timeline-icon">
								<i class="fa fa-cog" aria-hidden="true"></i>
								</div>
								<div class="content">
								<h3 class="title">Baby steps!</h3>
								<p class="description">
								Steve and his friends gather and are impressed by Steve’s motto, As a thought of giving it a chance and thinking over, Stumbling upon various ideas to grant better life to mankind. They come to an agreement to give it a try with Forex Trading. Team begins its preparations, studies, analysis and start planning their strategies all over till the year end.
								</p>
								</div>
								</a>
								</div>
								<div class="timeline">
								<a href="#" class="timeline-content">
								<span class="timeline-year">2016 Q2</span>
								<div class="timeline-icon">
								<i class="fa fa-heart" aria-hidden="true"></i>
								</div>
								<div class="content">
								<h3 class="title">Failure is the Biggest step to Success</h3>
								<p class="description">
								Not so pro, Not so warm. Getting exposed to the new world was difficult for Steve as well as his Team. Facing a lot of hardships and Setbacks, Nothing could kill the dream of Steve once dreamt of! Focused on his path, walking barefoot in the hail hitting him. Keeping the spark of hope and dedication moving ahead in spite of the losses. The initial days in forex trading were tough for the no pro Steve and his team.
								</p>
								</div>
								</a>
								</div>
								<div class="timeline">
								<a href="#" class="timeline-content">
								<span class="timeline-year">2016 Q2</span>
								<div class="timeline-icon">
								<i class="fa fa-globe" aria-hidden="true"></i>
								</div>
								<div class="content">
								<h3 class="title">Stable and Proficient</h3>
								<p class="description">
								The strategies were bouncing back some good response and a ray of hope shimmered across the team. The profits were raking and risk: reward ratio went positive , The team excelled and made very good profits. Steve himself is an Animal Lover and Nature Enthusiast. Steve has made various contributions towards it. Team has also granted a hand in Cancer cure.
								</p>
								</div>
								</a>
								</div>
								<div class="timeline">
								<a href="#" class="timeline-content">
								<span class="timeline-year">2017</span>
								<div class="timeline-icon">
								<i class="fa fa-apple" aria-hidden="true"></i>
								</div>
								<div class="content">
								<h3 class="title">Increment and Expansion</h3>
								<p class="description">
								Year 2017 was important for Steve as he was going make big decisions which could have put him in jeopardy too. But his bold attitude made him race through hardships and obstacles like a comet! He had plans of going global. His team was scared, that the couldn’t handle it. But Steve was Stubborn and didn’t bat an ear to anybody! He finally decided to go Global and at full potential. He had this confidence in him, that it will go large!
								</p>
								</div>
								</a>
								</div>
								<div class="timeline">
								<a href="#" class="timeline-content">
								<span class="timeline-year">2018 Q1</span>
								<div class="timeline-icon">
								<i class="fa fa-edit" aria-hidden="true"></i>
								</div>
								<div class="content">
								<h3 class="title">Global Launch</h3>
								<p class="description">
								Treaties signed! Got the legalisations of the platform and team started working day and night handling the heavy traffic and recruiting efficient staff, they accomplished various milestones by going global and digital. Amazing business plans were introduced to ensure the safety of investors. Various strategies were implemented to expand the network. Precautions and safety measures have been undergone for the safety of funds of the investors.
								</p>
								</div>
								</a>
								</div>
								</div>
								</div>
								</div>
								</div> 
                            </div>   
    	
       	