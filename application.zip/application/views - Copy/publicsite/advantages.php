
		<!-- Header --> 
 
		<style>
			.box-side-icon{
				height: 330px !important;
			}

			.imagebg img{
				display: none;
			}

			@media only screen and (max-width: 767px) {
              .box-side-icon{
				height: 200px !important;
				

			    }

			    .footer-section{
			    	    margin-top: -200px !important;
			    }

			    
			}
         
         @media only screen and (max-width: 992px) {
			.section-pad{
                position: relative;
                  top: -180PX;
              }

			}
			/*.header-s1 is-sticky{
 height: 300px;
}*/
.box-side-icon span{
	font-size: 25px!important;
	color: #ee853c!important;
}
.bg-image-loaded{
	background-image: url('publicsite/images/our_mission_and_vision.jpg') !important;
}
.box-side-icon{
	background-color: 
}
		</style>
		<header class="site-header header-s1 is-sticky">
			
			<?php $this->load->view("publicsite/common_header"); ?>

			<div class="page-head section row-vm light wow lightSpeedIn">
				<div class="imagebg i_c23">
					<img src="publicsite/images/adv1.jpg" alt="page-head">
				</div>
				<div class="container">
					<div class="row text-center i_c24">
						<div class="col-md-12">
							<h2>Advantages</h2>
							<div class="page-breadcrumb">
								<ul class="breadcrumb">
									<li><a href="<?php echo base_url('publicsite/index');?>">Home</a></li>
									<li class="active"><span>Advantage</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- #end Banner/Slider -->
		</header>
       	<!--Section -->
<div class="section section-pad">
	<div class="container"> 
		<div class="row"> 
			<div class="col-md-8">
			 <div class="text-block i_c30"> 
			 	<h3> OUR MISSION AND VISION</h3>
			 	<p><b>Our MISSION</b> is to contribute to the global community through the daily application of RYTHM – Raise Yourself To Help Mankind. We do this by helping individuals achieve their goals and lead better lives through a combination of an entrepreneurial business opportunity with life-enhancing products.</p>

			 	 
			 	<p> <b>Our VISION </b> is to be the global eCommerce leader within the direct selling industry, leveraging this position so as to be a positive influencer in the development of sustainable and professional network marketing communities around the world.
			 		<p><b>QNET's</b> core values are inspired by Mahatma Gandhi, our Corporate Icon, and built on RYTHM - Raise Yourself To Help Mankind, they are:</p>
			 		<p><b>INTEGRITY</b> Truth above all. Truth in all!</p>
			 		<p><b>Integrity in thought,</b>  word and action.</p>
			 		<p><b>SERVICE</b> We serve to lead and lead to serve. Service to all is our credo.</p>
			 		<p> <b>SUSTAINABILITY</b> We are merely caretakers for the next generation. We must preserve, sustain and even resurrect.</p>
			 		<p><b>LEADERSHIP</b> Lead to Inspire and Inspire to Lead! We nurture and inculcate entrepreneurial passion as the path to independence, inclusiveness and innovation.</p>

			 	</p> 
			 	<h3></h3>
			 </div> 
			 <div class="text-block i_c30">
			  <h3>Trade all leading markets with convenience and also safety</h3> 
			  <ul>
			   <li>Solid financial history and operational expertise.</li> 
			   <li>Bitcoin is Regulated and Authorized in various jurisdictions like UK, British Virgin Island and Dubai.</li> 
			   <li>Security and safety of Customer Funds policy, 100% isolation of retail customer funds with top-level banks, straight forward and transparent deposit, as well as withdrawal policy.</li> 
			</ul>
			 </div> 
			</div>
			 <div class="col-md-4"> 
			 	<img src="publicsite/images/download (2).jpg" alt="photo-md">
			 	 </div> 
			 	</div> 
			 	<div class="gaps size-2x"></div> 
			 	<div class="row">
			 	 <div class="col-md-12">
			 	  <div class="text-block i_c30">
			 	   
			 	     </div> 
			 	 </div> 
			 	</div> 
			 </div> 
			</div>



     <!--   	<div class="section section-pad">
       		<div class="container">
       			<div class="row row-vm">
       				<div class="col-md-6">
						<div class="text-block">
							<h2>What is Bitfair Mining?</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
							<p>Tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
							<a href="#" class="btn btn-alt">get started</a>
						</div>
       				</div>
       				<div class="col-md-1"></div>
       				<div class="col-md-5 tab-center">
       					<div class="round res-m-bttm"><img src="publicsite/images/mining.jpg" alt="photo-md"></div>
       				</div>
       			</div>
       			<div class="gaps size-3x"></div>
       			<div class="row row-vm reverses">
       				<div class="col-md-6 tab-center">
       					<div class="round res-m-bttm"><img src="publicsite/images/Hashrate.png" alt="photo-md"></div>
       				</div>
       				<div class="col-md-6 res-m-bttm">
						<div class="text-block">
							<h2>What are Bitfair Hashes?</h2>
							<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
							<p>Tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
							<a href="#" class="btn btn-alt">get started</a>
						</div>
       				</div>
       			</div>
       		</div>
       	</div> -->
       	<!--End Section -->
      
       	<!--Section -->
       	<div class="section section-pad">
       		<div class="container">
       			<div class="row">
       				<div class="col-md-5 col-sm-6 res-m-bttm">
       					<div class="box-side-icon payment_box" >
       						<span class="pe pe-7s-server"></span>
       						<div style="margin-top: -40px;">
							<h4>SPEEDY PAYMENT</h4>
							
							<p>The QNET,Values the Speed of the Deposits and Withdrawals.All Deposits and Withdrawals are Processed Instantly to your Account at High Speed and Totally Secure.</p>
      						<a href="#" class="read-more">Read More..</a>
      					</div>
       					</div>
       				</div>
       				<div class="col-md-5 col-sm-6 col-md-offset-1">
       					<div class="box-side-icon payment_box">
       						<span class="pe pe-7s-lock"></span>
       						<div style="margin-top: -40px;">
							<h4>Strong Security</h4>
							<p>Be QNET knows the Online Investment Market, and our Company Guarantees the Payment for all our Investors and Representatives. Invest Today at QNET and Get 2% Upto 12% Daily Forever.</p>
      						<a href="#" class="read-more">Read More..</a>
       					</div>
       				</div>
       				</div>
       				<div class="gaps size-2x"></div>
       			</div>
       			<div class="row">
       				<div class="col-md-5 col-sm-6 res-m-bttm">
       					<div class="box-side-icon" style="height: 250px;">
       						<span class="pe pe-7s-phone"></span>
       						<div style="margin-top: -40px;">
							<h4>Mobile Apps</h4>
							<p>Morbi eget varius risus, ut venenatis libero. Pellentesque in porta dui, euismod eleifend odio.</p>
      						<a href="#" class="read-more">Read More..</a>
       					</div>
       				</div>
       				</div>
       				<div class="col-md-5 col-sm-6 col-md-offset-1">
       					<div class="box-side-icon">
       						<span class="pe pe-7s-refresh"></span>
       						<div style="margin-top: -40px;">
							<h4>Recurring Buys</h4>
							<p>Be QNET, Specialized in Network Marketing and Digital Marketing. We offer 3 Safe Investment Plans that yield 2% to 12% Daily Forever. At QNET, all Deposits and Withdrawals are Instantaneous to your Account.</p>
      						<a href="#" class="read-more">Read More..</a>
       					</div>
       				</div>
       				</div>
       			</div>
       		</div>
       	</div>
       	<!--End Section -->
         	