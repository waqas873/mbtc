<style>
      #service h5{
            color:#ea670c!important;
      }
       #service p{
            color:#fff!important;
      }
      .btn.btn-alt{
            color: grey!important;
      }
      .btn.btn-alt:hover{
            color: #fff!important;
      }
      .section-head p{
            color: #b5b3b3!important;
      }
      
</style>
	
		<!-- Header --> 
		<header class="site-header header-s1 is-sticky">

			<?php $this->load->view("publicsite/common_header"); ?>

			<div class="page-head section row-vm light wow lightSpeedIn">
                        <div class="imagebg i_c23">
					<img src="publicsite/images/education.jpg" alt="page-head">
				</div>
				<div class="container">
					<div class="row text-center i_c24">
						<div class="col-md-12">
							<h2>About Us</h2>
							<div class="page-breadcrumb">
								<ul class="breadcrumb">
									<li><a href="<?php echo base_url('publicsite/index');?>">Home</a></li>
									<li class="active"><span>About Us</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- #end Banner/Slider -->
		</header>
    		
     	<!--Section -->
       	<div class="section section-pad wow bounceInUp i_c22" style="margin-top: 150px;">
       		<div class="container">
       			<div class="row row-vm">
       				<div class="col-md-5 res-m-bttm">
						<div class="text-block animated fadeInLeft">
                                          <br>
							<h2>About Our Plan</h2>
                                          <p>Now our Professional Referral Network Marketing: We Pay Commissions Three Kind Of Way,First Of All For Our Brilliant Networker (12% Smart Referal Bonus,And Second 8% Matching Solid Bonus)For Our Respective Investors We Present Beatifull ROI Bonus Daily 2% Upto 12%.Representatives. being an investor or Representative, you can Contact our Support by Email or WhatsApp,12 hours a day and 7 days a week.</p>
							<br>
                                          <ul>

								<li>you can exchange your QNet by eth.</li>
								<li>best profite bitco.exge for all over the world.</li>
								<li>we take a big missoin for growth business. </li>
								<li>we have top lavel QNet experts</li>
							</ul>
							<a href="#" class="btn btn-alt">Read More</a>
						</div>
       				</div>
       				<div class="col-md-6 col-md-offset-1">
       					<div class="video-block round">
                                          <div class="video">
                                               <!-- <img src="publicsite/images/unnamed.jpg" alt="photo-md" class="img-shadow"> -->
                                               <!-- <video width="500" controls>
                                                  <source src="publicsite/videos/bitfair_video.mp4" type="video/mp4">
                                                </video> -->
                                               <!--  <iframe width="560" height="315" src="https://www.youtube.com/embed/4oqFb14oKW4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe> -->
                                          </div>
       					</div>
       				</div>
       			</div>
       		</div>
       	</div>
       	<!--End Section -->
       	
       	<!--Section -->
       	<div class="section section-pad bg-grey wow fadeInLeft">
       		<div class="container">
       			<div class="section-head">
					<div class="row text-center">
						<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
							<h2 class="heading-section animated bounceInUp">Why choose Us</h2>
							<p style="color: ">Sed ut perspi ciatis unde omnis iste natus error sit volup tatem accusa ntium dolor emque lauda ntium, totam rem aperiam</p>
						</div>
					</div>
       			</div>
       			<div class="gaps size-3x"></div>
				<div class="row text-center">
					<div class="col-md-4 col-sm-4 res-m-bttm-lg">
						<div class="box-alt" >
							<div class="image-icon">
								<img src="publicsite/images/box-icon-f.png" alt="box-icon">
							</div>
							<h4>SPEEDY PAYMENT</h4>
                                          <p>The QNet Company,Values the Speed of the Deposits and Withdrawals.All Deposits and Withdrawals are Processed Instantly to your Account at High Speed and Totally Secure.</p>
 					</div>
                        </div>
					<div class="col-md-4 col-sm-4">
						<div class="box-alt" >
							<div class="image-icon">
								<img src="publicsite/images/box-icon-g.png" alt="box-icon">
							</div>
							<h4>Strong Security</h4>
                                          <p>Be QNet Company knows the Online Investment Market, and our Company Guarantees the Payment for all our Investors and Representatives. Invest Today at QNET Company and Get 2% to 12% Daily Forever.</p>
						</div>
					</div>
					<div class="col-md-4 col-sm-4">
						<div class="box-alt"  >
							<div class="image-icon">
								<img src="publicsite/images/box-icon-h.png" alt="box-icon">
							</div>
							<h4>World Coverage</h4>
                                          <p>Be QNet Company offers the best Investment Plans. You can Invest from anywhere in the World and Withdraw your Earnings at any time.</p>
						</div>
					</div>
				</div>
       		</div>
       	</div>
       	<!--End Section -->
       	
       	<!--Section -->
       	<div class="section section-pad wow bounceInUp bg-grey">
       		<div class="container">
       			<div class="section-head">
					<div class="row text-center">
						<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
							<h2 class="heading-section">what you can do ?</h2>
							<p>Sed ut perspi ciatis unde omnis iste natus error sit volup tatem accusa ntium dolor emque lauda ntium, totam rem aperiam</p>
						</div>
					</div>
       			</div>
       			<div class="gaps size-3x"></div>
       			<div class="row text-center">
       				<div class="row" id="service">
       				<div class="col-md-4 col-sm-6">
       					<div class="service-box shadow round">
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/images 123.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry" style="height: 265px;">
       							<h5>Buy QNet Online</h5>
                                                <p>VeriSign SSL & ESSL Security protocols.2FA security employed. CyberTrust Security accreditation. QNET’s web and mobile sites are certified by TRUSTe.
                                                World-class data centres in Hong Kong and Malaysia.</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
						<div class="gaps size-3x"></div>
       				</div>
       				<div class="col-md-4 col-sm-6">
       					<div class="service-box shadow round" >
       						<div class="service-thumb" >
       						    <a href="#"><img src="publicsite/images/metd_qnet_randeep_1.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry"  style="height: 265px;">
       							<h5>sell Qnet</h5>
       							<p>Justo dolor pede pede sit. Eu amet eos mauris, iaculis in, fringilla diam eros erat, fermentum etiam parturient est adipiscing</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
						<div class="gaps size-3x"></div>
       				</div>
       				<div class="col-md-4 col-sm-6">
       					<div class="service-box shadow round">
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/UKR NY CSR Comms.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry"  style="height: 265px;">
       							<h5>Earn Passive Income</h5>
                                                <p>We Pay Commissions Three Kind Of Way,First Of All For Our Brilliant Networker (12% Smart Referal Bonus,And Second 8% Matching Solid Bonus)</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
						<div class="gaps size-3x"></div>
       				</div>
       					<div class="col-md-4 col-sm-6 res-m-bttm-3x">
       					<div class="service-box shadow round">
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/nfz8u3njm9c3x5qbhloq.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry"  style="height: 265px;">
       							<h5>Strong Securiy</h5>
                                                <p>Be QNet Company knows the Online Investment Market, and our Company Guarantees the Payment for all our Investors and Representatives. Invest Today at QNet Company and Get 2% to 12% Daily Forever.</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
       				</div>
       				<div class="col-md-4 col-sm-6 res-m-bttm-3x">
       					<div class="service-box shadow round">
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/download1277.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry"  style="height: 265px;">
       							<h5>Build Your Reputation</h5>
                                                <p>You can join us.By joining us within a short period of time you will be the one of nine and half hundered millionares. You can spend your respectful life.</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
       				</div>
       				<div class="col-md-4 col-sm-6 res-m-bttm-3x">
       					<div class="service-box shadow round">
       						<div class="service-thumb">
       							<a href="#"><img src="publicsite/images/iphine82968158_1920_1024x.jpg" alt="service"></a>
       						</div>
       						<div class="service-entry"  style="height: 265px;">
       							<h5>Get A Free Wallet</h5>
                                                <p>We provide new wallets to our all new customers.They can start their new future.</p>
       							<a href="#" class="btn-icon"><span class="pe pe-7s-angle-right"></span></a>
       						</div>
       					</div>
       				</div>
       				</div>
       			</div>
       		</div>
       	</div>
       	<!--End Section -->
       	
       	
    	<!-- Section -->
    	<div class="section section-pad cta-section light has-bg dark-filter i_c21 wow slideInRight">
    		<div class="imagebg has-parallax i_c19">
				<img src="publicsite/images/chart.jpg" alt="cta-bg">
			</div>
    		<div class="container">
    			<div class="row text-center i_c20">
    				<div class="col-md-8 col-md-offset-2">
    					<h3>Are you searching for a quick, cheap, and safe way to buy QNet? </h3>
    					<a href="#" class="btn btn-md">buy QNet</a>
    				</div>
    			</div>
    		</div>
    	</div>
     	<!-- End Section -->
      	
       	<!--Section -->
       	<!-- <div class="section section-pad wow bounceInUp">
       		<div class="container">
       			<div class="section-head">
					<div class="row text-center">
						<div class="col-md-6 col-md-offset-3 col-md-offset-3 col-sm-8 col-sm-offset-2">
							<h2 class="heading-section">our expert team</h2>
							<p>Sed ut perspi ciatis unde omnis iste natus error sit volup tatem accusa ntium dolor emque lauda ntium, totam rem aperiam</p>
						</div>
					</div>
       			</div>
       			<div class="gaps size-3x"></div>
       			<div class="row text-center">
       				<div class="col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-2 res-m-bttm">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="publicsite/images/men1.jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<div class="team-info">
       							<h5 class="team-name">jonson makerson</h5>
       							<span class="team-title">consultant</span>
       						</div>
       					</div>
       				</div>
       				<div class="col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-2 res-m-bttm">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="publicsite/images/men2.jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<div class="team-info">
       							<h5 class="team-name">nikon tupora</h5>
       							<span class="team-title">team leader</span>
       						</div>
       					</div>
       				</div>
       				<div class="col-md-4 col-md-offset-0 col-sm-8 col-sm-offset-2 res-m-bttm">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="publicsite/images/men3.jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<div class="team-info">
       							<h5 class="team-name">jahidul hossen</h5>
       							<span class="team-title">borker</span>
       						</div>
       					</div>
       				</div>
       			</div>
       		</div>
       	</div> -->
       	<!--End Section -->
       	
       	<!--Section -->
       	<div class="section section-pad wow slideInRight" style="ba">
                  <div class="container">
                        <div class="section-head">
                              <div class="row text-center">
                                    <div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                                          <h2 class="heading-section">What investors say</h2>
                                          <p>Sed ut perspi ciatis unde omnis iste natus error sit volup tatem accusa ntium dolor emque lauda ntium, totam rem aperiam</p>
                                    </div>
                              </div>
                        </div>
                        <div class="gaps size-3x"></div>
                        <div class="row text-center">
                              <div class="col-md-6 col-md-offset-3">
                                    <div class="testimonial-carousel has-carousel" data-items="1" data-loop="true" data-dots="true" data-auto="true" style="margin-bottom: -10%;">
                                          <div class="testimonial-item">
                                                <div class="client-photo circle">
                                                      <img src="publicsite/images/QNET-1-300x200.jpg" alt="client">
                                                      <em class="fa fa-quote-right"></em>
                                                </div>
                                                <blockquote>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi.</blockquote>
                                                <div class="client-info">
                                                      <h6>Vijay Eswaran</h6>
                                                      <span>CEO, Company Name</span>
                                                </div>
                                          </div>
                                          <div class="testimonial-item">
                                                <div class="client-photo circle">
                                                      <img src="publicsite/images/images (1).jpg" alt="client">
                                                      <em class="fa fa-quote-right"></em>
                                                </div>
                                                <blockquote>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi.</blockquote>
                                                <div class="client-info">
                                                      <h6>Vijay Eswaran</h6>
                                                      <span>CEO, Company Name</span>
                                                </div>
                                          </div>
                                          <div class="testimonial-item">
                                                <div class="client-photo circle">
                                                      <img src="publicsite/images/nfz8u3njm9c3x5qbhloq.jpg" alt="client">
                                                      <em class="fa fa-quote-right"></em>
                                                </div>
                                                <blockquote>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi.</blockquote>
                                                <div class="client-info">
                                                      <h6>Vijay Eswaran</h6>
                                                      <span>CEO, Company Name</span>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                        </div>
                  </div>
            </div>
       	<!--End Section -->
       	
       	<!-- Section -->
		    <div id="carousel3d">
  <carousel-3d :perspective="0" :space="200" :display="5" :controls-visible="true" :controls-prev-html="'❬'" :controls-next-html="'❭'" :controls-width="30" :controls-height="60" :clickable="true" :autoplay="true" :autoplay-timeout="5000">
    <slide :index="0">
      <span class="title">You know</span>
    <img src="publicsite/images/bt1.png">
    </slide>
            <!-- <slide :index="1">

        <span class="title">You know</span>
         <img src="publicsite/images/bt2.png">
    </slide> -->
            <!-- <slide :index="2">
      <span class="title">You know</span>
   <img src="publicsite/images/bt3.png">
    </slide> -->
           <!--  <slide :index="3">
      <span class="title">You know</span>
       <img src="publicsite/images/bt4.png">
    </slide>
            <slide :index="4">
     <span class="title">You know</span>
  <img src="publicsite/images/bt5.png">
    </slide>
            <slide :index="5">
      <span class="title">You know</span>
      <img src="publicsite/images/bt6.png">
    </slide>
            <slide :index="6">
      <span class="title">You know</span>
      <img src="publicsite/images/bt7.png">
    </slide> -->
            
  </carousel-3d>
</div>
		<!-- End Section -->
		
 