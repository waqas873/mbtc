
	        <style>
                    .i_c22{
                     margin-top: 0 !important;
                    } 
                    
                     .imagebg{
                            background-image: none !important;
                     }

                     .section-pad{
                            margin-top: 30%;
                     }

                   @media only screen and (max-width: 992px) { 
                        .section-pad{
                            margin-top: -300px;
                        }
                       
                     }

                  @media only screen and (max-width: 767px) {   

                     .i_c24 h2{
                            position: relative;
                           top: -40px;
                         }

                         .i_c24 .breadcrumb{
                            position: relative;
                           top: -40px;
                         }

                     }


                     @media only screen and (max-width: 767px) {   

                     .i_c24 h2{
                            position: relative;
                           top: -100px;
                         }

                         .i_c24 .breadcrumb{
                            position: relative;
                           top: -100px;
                         }



                     }

#img img{
  width: 100%;
  height: 220px;
}


               </style>
		<!-- Header --> 
		<header class="site-header header-s1 is-sticky">
			
			<?php $this->load->view("publicsite/common_header"); ?>

			<!-- #end Navbar -->
			<!-- Banner/Slider -->
			<div class="page-head section row-vm light wow lightSpeedIn">
				<div class="imagebg i_c23">
					<img src="assets /images/branding_and_sports_sponsorships.jpg" alt="page-head">
				</div>
				<div class="container">
					<div class="row text-center i_c24">
						<div class="col-md-12">
							<h2>Expert Team</h2>
							<div class="page-breadcrumb">
								<ul class="breadcrumb">
									<li><a href="<?php echo base_url('publicsite/index');?>">Home</a></li>
									<li class="active"><span>Teams</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- #end Banner/Slider -->
		</header>

		<div class="section section-pad"> 
			<div class="container"> 
				<div class="row row-vm"> 
					<div class="col-md-6 res-m-bttm wow fadeInLeft"> 
						<div class="text-block">
            
							<h3>Dato sri <span>Vijay Eswaran  </span> ( CEO )</h3> 
                <h5>Joseph  <span>Bismark  </span> ( Founder )</h5> 
							<p class="text-justify">QNET is one of Asia’s leading crypto trading, offering meaningfull products in diverse markets. Our focus is to enable people to rise through solutions that power entrepreneurship and enhance lifestyles.

QNET’s grass-roots business model enables ordinary people from all walks of life to start their own business with minimal overhead. With hard work and dedication, QNET distributors, known as Independent Representatives (IRs), have the opportunity to become economically self-sufficient, improving the lives of their families and communities as well as helping others to achieve their dreams.

At QNET, we are driven by two important philosophies: RYTHM and In-Service.

QNET’s founders are profoundly inspired by the life and work of Gandhi, a great leader, humanitarian and activist. The teachings of Gandhi laid the foundation for RYTHM − Raise Yourself to Help Mankind. The idea of empowering others to succeed in order to be successful lies at the core of our business.We advocate the concept of In-Service as an important characteristic of leadership. Our founders have instilled a very strong culture of service above self, in both the employees and the network. We believe that serving others with humility is the true hallmark of a leader.QNET recognizes that people are our greatest assets. Our distribution network’s boundless energy is fuelled by a collective aspiration to achieve financial independence. We are dedicated to giving our IRs the tools and education they need to strengthen their understanding of our products and business model and we are engaged in developing them on a personal level.

At QNET, we celebrate ethnic and cultural diversity. Our leadership team and employees are drawn from more than 30 different countries and our customers are present in more than 100 countries. We take pride in being the veritable United Nations of network marketing!
</p>
                                                  <h3>CEO Message</h3> 
							 <p class="text-justify">The feature of network marketin is unlimited.There's no end in sight.It will continue to grow because better people are getting into it.
It would be one of the more respected business method in the world.
Network markiting creats more millioners than any other industry.Dare to dream,Dream big when you do and let no one tell you that you have to settle 
for Anything less that every thing your heart desires.</p>
					    </div> 
					</div> 
					<div class="col-md-1"></div>
							<div class="col-md-5 wow fadeInRight" style="margin-top: -100px;"> 
                <div class="row" id="img">
                  <div class="col-md-6 text-center" >
                  <img src="assets/images/download (4).jpg" alt="Steve Murray" class="img-shadow">   
                  </div>
                  <div class="col-md-6 text-center" >
                  <img src="assets/images/images (4).jpg" height="220" width="100%" alt="Steve Murray" class="img-shadow">    
                  </div>
                  <br>
                  <br>
                  <div class="video-block round" style="margin-top: 10px;"> 
                  <div style="margin-top: 10px;">
                <iframe width="560" height="315" style="margin-top: 10px;" src="https://www.youtube.com/embed/z2kVvROZ0ho" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
                </div>


                </div>
															</div> 
				</div>
			</div> 
		</div>
    	
     	<!--Section -->
       	<div class="section section-pad wow rollIn i_c22">
       		<div class="container">
       			<div class="row text-center">
       				<div class="col-md-4 col-sm-6">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="assets/images/20170806_113457.jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<!-- <div class="team-info">
       							<h5 class="team-name">jonson makerson</h5>
       							<span class="team-title">consultant</span>
       						</div> -->
       					</div>
						<div class="gaps size-1-5x"></div>
       				</div>
       				<div class="col-md-4 col-sm-6">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="assets/images/2141.jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<!-- <div class="team-info">
       							<h5 class="team-name">nikon tupora</h5>
       							<span class="team-title">team leader</span>
       						</div> -->
       					</div>
						<div class="gaps size-1-5x"></div>
       				</div>
       				<div class="col-md-4 col-sm-6">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="assets/images/h1.jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<!-- <div class="team-info">
       							<h5 class="team-name">jahidul hossen</h5>
       							<span class="team-title">borker</span>
       						</div> -->
       					</div>
						<div class="gaps size-1-5x"></div>
       				</div>
       				<div class="col-md-4 col-sm-6 res-m-bttm">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="assets/images/download (5).jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<!-- <div class="team-info">
       							<h5 class="team-name">Thomas George</h5>
       							<span class="team-title">consultant</span>
       						</div> -->
       					</div>
       				</div>
       				<div class="col-md-4 col-sm-6 res-m-bttm">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="assets/images/download (4).jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<!-- <div class="team-info">
       							<h5 class="team-name">Adrienne Alex</h5>
       							<span class="team-title">team leader</span>
       						</div> -->
       					</div>
       				</div>
       				<div class="col-md-4 col-sm-6">
       					<div class="team-member">
       						<div class="team-thumb">
       							<img src="assets/images/images1 .jpg" alt="team-thumb">
       							<div class="team-thumb-overlay">
       								<ul class="team-social">
       									<li><a href="#"><span class="fa fa-facebook"></span></a></li>
       									<li><a href="#"><span class="fa fa-twitter"></span></a></li>
       									<li><a href="#"><span class="fa fa-instagram"></span></a></li>
       								</ul>
       							</div>
       						</div>
       						<!-- <div class="team-info">
       							<h5 class="team-name">William Rhys</h5>
       							<span class="team-title">borker</span>
       						</div> -->
       					</div>
       				</div>
       			</div>
       		</div>
       	</div>
       	<!--End Section -->
       	
       	