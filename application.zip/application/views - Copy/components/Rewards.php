<div>
	<h2 style="text-align:center;">Rewards</h2>
</div>
<div class="row" style="margin-top:10px;">
	<table class="table table-hover table-striped table-responsive">
		<thead>
			<tr>
			
				<th>Right Investment</th>
				<th>Left Investment</th>
				<th>Reward</th>
				<th>Status</th>
				
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>5000</td>
				<td>5000</td>
				<td>$50</td>
				<td><span class="badge badge-success">Unlocked</span></td>
			</tr>

			<tr>
				<td>10000</td>
				<td>10000</td>
				<td>$100</td>
				<td><span class="badge badge-warning">locked</span></td>
			</tr>

			<tr>
				<td>50000</td>
				<td>50000</td>
				<td>Iphone Xs</td>
				<td><span class="badge badge-warning">locked</span></td>
			</tr>

			<tr>
				<td>100000</td>
				<td>100000</td>
				<td>Trip</td>
				<td><span class="badge badge-warning">locked</span></td>
			</tr>

			<tr>
				<td>500000</td>
				<td>500000</td>
				<td>1800cc Car</td>
				<td><span class="badge badge-warning">locked</span></td>
			</tr>


		</tbody>
	</table>
</div>