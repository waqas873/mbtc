<div class="row">
	<h1 class="page-title">User Packages</h1>
<table id="table"> 
	<thead>
		<tr>
			<th>Package Id</th>
			<th>Package Name</th>
			<th>Package Roi</th>
			<th>Package Fees</th>
			<th>Bought on</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>1</td>
			<td>Starter</td>
			<td>10.29</td>
			<td>2%</td>
			<td>2018-08-10</td>
		</tr>
	</tbody>
</table>
</div>