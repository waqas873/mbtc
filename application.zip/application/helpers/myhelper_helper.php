<?php 

function a(){
	exit();
}


 ?>