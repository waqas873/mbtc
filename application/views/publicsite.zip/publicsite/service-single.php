
	
		<!-- Header --> 
		<header class="site-header header-s1 is-sticky">
			
			<?php $this->load->view("publicsite/common_header"); ?>

			<div class="page-head section row-vm light">
				<div class="imagebg">
					<img src="publicsite/images/123.jpg" alt="page-head">
				</div>
				<div class="container">
					<div class="row text-center">
						<div class="col-md-12">
							<h2>Service Single</h2>
							<div class="page-breadcrumb">
								<ul class="breadcrumb">
									<li><a href="<?php echo base_url('publicsite/index');?>">Home</a></li>
									<li class="active"><span>Service Single</span></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!-- #end Banner/Slider -->
		</header>
    	
     	<!--Section -->
       	<div class="section section-pad">
       		<div class="container">
       			<div class="row row-vm">
       				<div class="col-md-8">
						<div class="text-block">
							<h2>Buy Bitcoin Online</h2>
							<p>Lorem ipsum dolor sit amet, conse ctetur adipi scing elit, sed do eiusmod tempor incidi dunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exerc itation ullamco laboris.Tempor inci didunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exerci tation ullamco laboris  idunt ut labore et dolore magna aliqua.</p>
							<p>Sed do eiusmod tempor incid idunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exerc itation ullamco laboris.Tempor inci didunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exerci tation ullamco laboris.</p>
						</div>
       				</div>
       				<div class="col-md-4">
       					<div class="round mgr--30 res-m-bttm"><img src="publicsite/images/Money.jpg" alt="photo-md" class="img-shadow"></div>
       				</div>
       			</div>
       		</div>
       	</div>
       	<!--End Section -->
       	
       	<!-- Section -->
		<div class="section section-pad bg-grey">
			<div class="container">
				<div class="row">
    				<div class="col-md-8">
    					<div class="text-block">
							<h3>Buy Bitcoin Instantly from a Safe Exchange</h3>
							<p>Many services nowadays offer their users to buy Bitcoins, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc et lorem nec felis finibus laoreet. The company is officially registered in the UK, has a Money Services Busialiquam tellus, sit amet tristique ipsum. </p>
							<p>Many services nowadays offer their users to buy Bitcoins, Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc et lorem nec felis finibus laoreet. The company is officially registered in the UK has a Money Services Business status.</p>
						</div>
    				</div>
    				<div class="col-md-4">
    					<div class="icon-block">
    						<div class="icon-image">
    							<img src="publicsite/images/icon-a.png" alt="icon">
    						</div>
    						<p>Many services nowadays offer their users to buy Bitcoins, Lorem ipsum dolor sit</p>
    						<ul>
    							<li>Lorem ipsum dolor sit amet.</li>
    							<li>Many services nowadays offer.</li>
    							<li>Busialiquam tellus, sit amet.</li>
    						</ul>
    					</div>
    				</div>
    			</div>
			</div>	
		</div>
		<!-- End Section -->
		
		<!--Section -->
       	<div class="section section-pad">
       		<div class="container">
       			<div class="section-head">
					<div class="row text-center">
						<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
							<h2 class="heading-section">Why this service ?</h2>
							<p>Sed ut perspi ciatis unde omnis iste natus error sit volup tatem accusa ntium dolor emque lauda ntium, totam rem aperiam</p>
						</div>
					</div>
       			</div>
       			<div class="gaps size-3x"></div>
				<div class="row text-center">
					<div class="col-md-4 res-m-bttm-lg">
						<div class="box-alt">
							<div class="image-icon">
								<img src="publicsite/images/box-icon-f.png" alt="box-icon">
							</div>
							<h4>Payment Options</h4>
							<p>Morbi eget varius risus, ut venenatis libero Pellentesque in porta dui.</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-alt">
							<div class="image-icon">
								<img src="publicsite/images/box-icon-g.png" alt="box-icon">
							</div>
							<h4>Strong Security</h4>
							<p>Morbi eget varius risus, ut venenatis libero Pellentesque in porta dui.</p>
						</div>
					</div>
					<div class="col-md-4">
						<div class="box-alt">
							<div class="image-icon">
								<img src="publicsite/images/box-icon-h.png" alt="box-icon">
							</div>
							<h4>World Coverage</h4>
							<p>Morbi eget varius risus, ut venenatis libero Pellentesque in porta dui.</p>
						</div>
					</div>
				</div>
       		</div>
       	</div>
       	<!--End Section -->
		
    	<!-- Section -->
    	<div class="section section-pad cta-section light has-bg dark-filter">
    		<div class="imagebg">
				<img src="publicsite/images/cta-bg.jpg" alt="cta-bg">
			</div>
    		<div class="container">
    			<div class="row text-center">
    				<div class="col-md-8 col-md-offset-2">
    					<h3>Are you searching for a quick, cheap, and safe way to buy Bitcoins? </h3>
    					<a href="#" class="btn btn-md">buy bitcoin</a>
    				</div>
    			</div>
    		</div>
    	</div>
     	<!-- End Section -->